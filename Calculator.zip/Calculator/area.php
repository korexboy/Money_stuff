<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Area of Rectangle and Square</title>
    <style>
        .green {
            color: red;
        }
        .red {
            color: green;
        }
    </style>
</head>
<body>
    <h1>Area of Square and Rectangle</h1>
    <form action="area.php" method="POST">
        <label for="length">Length:</label>
        <input name="length" type="number" placeholder="Input Length">
        <br>
        <label for="breadth">Breadth:</label>
        <input name="breadth" type="number" placeholder="Input Breadth">
        <br>
        <input type="submit" value="Calculate">
    </form>
    <?php 
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $length = filter_input(INPUT_POST, "length", FILTER_SANITIZE_NUMBER_FLOAT);
        $breadth = filter_input(INPUT_POST, "breadth", FILTER_SANITIZE_NUMBER_FLOAT);

        $errors = false;

        if (empty($length) || empty($breadth)) {
            echo "Please fill in all fields";
            $errors = true;
        }

        if (!is_numeric($length) || !is_numeric($breadth)) {
            echo "Please only write numbers";
            $errors = true;
        }

        if (!$errors) {
            $action = "calculatearea";
            $area = 0;
            switch ($action) {
                case "calculatearea":
                    $area = $length * $breadth;
                    break;
                default:
                    echo "Something went wrong";
                    break;
            }
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $color = ($area < 100) ? 'green' : 'red';
            }
            echo "<p class=\"$color\"> area = ". $area ."</p>";
        }

    }
    ?> 
</body>
</html>