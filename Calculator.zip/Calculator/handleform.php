<?php  
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $option=$_POST['option'];

    switch($option) {
        case 'area':
            header("Location: area.php");
            break;
        case 'simpleinterest' :
            header("Location: simpleinterest.php");
            break;
        default:
            header("Location: index.php");
            break;
    }
    exit();
}