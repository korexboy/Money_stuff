<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple Interest</title>
    <style>
        .green {
            color: red;
        }
        .red {
            color: green;
        }
    </style>
</head>
<body>
    <h1>Simple Interest</h1>
    <form action="simpleinterest.php" method="POST">
        <label for="principal">Principal:</label>
        <input name="principal" type="number" placeholder="Input Principal">
        <br>
        <label for="rate">Rate:</label>
        <input name="rate" type="number" placeholder="Input Rate">
        <br>
        <label for="time">Time:</label>
        <input name="time" type="number" placeholder="Input Time">
        <br>
        <button>Calculate</button>
    </form>
    <?php 
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $principal = filter_input(INPUT_POST, "principal", FILTER_SANITIZE_NUMBER_FLOAT);
        $rate = filter_input(INPUT_POST, "rate", FILTER_SANITIZE_NUMBER_FLOAT);
        $time = filter_input(INPUT_POST, "time", FILTER_SANITIZE_NUMBER_FLOAT);

        $errors = false;

        if (empty($principal) || empty($rate) || empty($time)) {
            echo "Please fill in all fields";
            $errors = true;
        }

        if (!is_numeric($principal) || !is_numeric($rate) || !is_numeric($time)) {
            echo "Please only write numbers";
            $errors = true;
        }

        if (!$errors) {
            $action = "calcsimpleinterest";
            $simpleinterest = 0;
            switch ($action) {
                case "calcsimpleinterest":
                    $simpleinterest = ($principal * $rate * $time)/100;
                    break;
                default:
                    echo "Something went wrong";
                    break;
            }
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $color = ($simpleinterest < 100) ? 'green' : 'red';
            }
            echo "<p class=\"$color\">Simple Interest = ". $simpleinterest ."</p>";
        }

    }
    ?> 
</body>
</html>