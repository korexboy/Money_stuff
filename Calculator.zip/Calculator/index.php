<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple Interest and Area Calculator</title>
</head>
<body>
    <h1>Simple Interest and Area Calculator</h1>
    <form action="handleform.php" method="POST">
        <label>Pick what you would like to do:</label>
        <select name="option" id="option">
            <option value="area">Area of rectangle or square</option>
            <option value="simpleinterest">Simple Interest</option>
        </select>
        <br>
        <input name="submit" type="submit">
    </form>
</body>
<footer>JOSHUA PRAISE IS GAY</footer>
</html>